# DeskThing App

The DeskThing App is a web application that allows you to manage your Bluetooth connections and RGB settings. The app provides a user-friendly interface that mimics a phone UI, making it easy to navigate and control.

## Features

- **Bluetooth Management**: Enable and manage Bluetooth connections with ease.
- **RGB Control**: Toggle and customize RGB background settings.
- **Swipe Gestures**: Use intuitive swipe gestures to navigate the app:
  - Swipe from top to bottom to open the main UI.
  - Swipe from left to right to open the left-side UI within a specific area.
  - Swipe from right to left to open the right-side UI within a specific area.
  - Swipe from bottom to top to close the main UI.
  - Tap outside the main UI and sidebars to close them.

## Installation

1. Clone the repository:
   ```sh
   git clone https://github.com/ItsRiprod/DeskThing.git
   ```
2. Navigate to the project directory:
   ```sh
   cd DeskThing
   ```
3. Open `index.html` in your preferred web browser.

## Usage

- **Enable Bluetooth**: Click the "Enable Bluetooth" button to request and connect to a Bluetooth device.
- **Toggle RGB Mode**: Click the "Toggle RGB Mode" button to cycle through different RGB modes ("Off," "Girly," "Boy," "Gaming," "On").
- **Swipe Gestures**: Use swipe gestures to navigate between different UIs and settings.

## Manifest File

The `manifest.json` file defines the app's metadata and configuration. Required fields include `id`, `isAudioSource`, `isWebApp`, `isLocalApp`, `requires`, `label`, `version`, `description`, `author`, `platforms`, `homepage`, and `repository`.

## Contributing

Contributions are welcome! Please follow these steps to contribute:

1. Fork the repository.
2. Create a new branch:
   ```sh
   git checkout -b feature/your-feature-name
   ```
3. Make your changes and commit them:
   ```sh
   git commit -m "Add your commit message"
   ```
4. Push to the branch:
   ```sh
   git push origin feature/your-feature-name
   ```
5. Open a pull request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Credits

- Developed by [Riprod](https://github.com/ItsRiprod).