import { SongData } from 'deskthing-server';

export function sendMessageToParent(app: string, request: string, type: string, data: any) {
  const payload = {
    app: app || 'yourAppName',
    type: type || 'message',
    request: request || null,
    data: data || null,
  };
  window.parent.postMessage(
    { type: 'IFRAME_ACTION', payload: payload },
    '*'
  );
}

export function nextTrack(id?: string) {
  sendMessageToParent('music', 'next', 'set', id);
}

export function previousTrack() {
  sendMessageToParent('music', 'previous', 'set');
}

export function rewind(seconds?: number) {
  sendMessageToParent('music', 'rewind', 'set', seconds);
}

export function fastForward(seconds?: number) {
  sendMessageToParent('music', 'fast_forward', 'set', seconds);
}

export function play(data?: { playlist?: string; id?: string; position?: number }) {
  sendMessageToParent('music', 'play', 'set', data);
}

export function pause(id?: string) {
  sendMessageToParent('music', 'pause', 'set', id);
}

export function seek(position_ms: number) {
  sendMessageToParent('music', 'seek', 'set', position_ms);
}

export function like(like: boolean) {
  sendMessageToParent('music', 'like', 'set', like);
}

export function setVolume(volume: number) {
  sendMessageToParent('music', 'volume', 'set', volume);
}

export function setRepeatMode(mode: 'off' | 'all' | 'track') {
  sendMessageToParent('music', 'repeat', 'set', mode);
}

export function setShuffleMode(shuffle: boolean) {
  sendMessageToParent('music', 'shuffle', 'set', shuffle);
}

export function getCurrentSong() {
  sendMessageToParent('music', 'song', 'get');
}