document.addEventListener('DOMContentLoaded', () => {
    let isBluetoothEnabled = false;
    let isConnected = false;
    const rgbModes = ['Off', 'Girly', 'Boy', 'Gaming', 'On'];
    let currentRgbModeIndex = 0;
    let colorInterval;
    let customTime = null;

    const girlyColors = ['#FFC0CB', '#FF69B4', '#D8BFD8', '#E6E6FA', '#F08080', '#FFE4E1', '#40E0D0'];
    const boyColors = ['#0000FF', '#1E90FF', '#4169E1', '#000080', '#4682B4', '#5F9EA0'];
    const gamingColors = ['#00FF00', '#ADFF2F', '#7FFF00', '#32CD32', '#9ACD32', '#6B8E23'];

    async function toggleBluetoothDevices() {
        if (!isBluetoothEnabled) {
            try {
                if (navigator.bluetooth) {
                    console.log('Requesting Bluetooth device...');
                    const device = await navigator.bluetooth.requestDevice({
                        acceptAllDevices: true,
                        optionalServices: ['battery_service']
                    });
                    console.log(`Connecting to GATT server of ${device.name}...`);
                    const server = await device.gatt.connect();
                    console.log('Connected to Bluetooth device successfully!');
                    document.getElementById('enableButton').classList.add('enabled');
                    document.getElementById('enableButton').textContent = 'Bluetooth Enabled';
                    isConnected = true;
                    updateConnectionStatus();
                } else {
                    console.log('Bluetooth is not supported on this browser.');
                }
            } catch (error) {
                console.error('Failed to enable Bluetooth:', error);
                isConnected = false;
                updateConnectionStatus();
            }
            isBluetoothEnabled = true;
        }
    }

    function updateConnectionStatus() {
        const statusElement = document.getElementById('connectionStatus');
        if (isConnected) {
            statusElement.textContent = 'Connected';
        } else {
            statusElement.textContent = 'Disconnected';
        }
    }

    function changeBackgroundColor(colors) {
        let index = 0;
        if (colorInterval) clearInterval(colorInterval);
        colorInterval = setInterval(() => {
            document.body.style.backgroundColor = colors[index];
            index = (index + 1) % colors.length;
        }, 1000);
    }

    function toggleRgbMode() {
        currentRgbModeIndex = (currentRgbModeIndex + 1) % rgbModes.length;
        const currentMode = rgbModes[currentRgbModeIndex];
        document.getElementById('toggleRgbButton').textContent = `Current Mode: ${currentMode}`;

        switch (currentMode) {
            case 'Girly':
                changeBackgroundColor(girlyColors);
                break;
            case 'Boy':
                changeBackgroundColor(boyColors);
                break;
            case 'Gaming':
                changeBackgroundColor(gamingColors);
                break;
            case 'On':
                changeBackgroundColor([...girlyColors, ...boyColors, ...gamingColors]);
                break;
            case 'Off':
            default:
                if (colorInterval) clearInterval(colorInterval);
                document.body.style.backgroundColor = 'black';
                break;
        }
    }

    function showClock() {
        const clockFrame = document.getElementById('clockFrame');
        clockFrame.style.display = 'flex';
        updateClock();
    }

    function updateClock() {
        const now = customTime ? new Date(customTime) : new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const timeString = `${hours}:${minutes}:${seconds}`;
        document.getElementById('clock').textContent = timeString;
        if (customTime) {
            customTime.setSeconds(customTime.getSeconds() + 1);
        }
        setTimeout(updateClock, 1000);
    }

    function setTime() {
        const hours = parseInt(document.getElementById('hours').value);
        const minutes = parseInt(document.getElementById('minutes').value);
        const seconds = parseInt(document.getElementById('seconds').value);
        customTime = new Date();
        if (!isNaN(hours)) customTime.setHours(hours);
        if (!isNaN(minutes)) customTime.setMinutes(minutes);
        if (!isNaN(seconds)) customTime.setSeconds(seconds);
        updateClock();
    }

    const clockButton = document.getElementById('clockButton');
    clockButton.addEventListener('click', showClock);

    const setTimeButton = document.getElementById('setTimeButton');
    setTimeButton.addEventListener('click', setTime);

    const enableButton = document.getElementById('enableButton');
    enableButton.addEventListener('click', toggleBluetoothDevices);

    const toggleRgbButton = document.getElementById('toggleRgbButton');
    toggleRgbButton.addEventListener('click', toggleRgbMode);

    const mediaPlayerButton = document.getElementById('mediaPlayerButton');
    mediaPlayerButton.addEventListener('click', () => {
        document.getElementById('blueContainer').classList.remove('hidden');
    });

    // Swipe detection with debug logs
    let touchstartX = 0, touchendX = 0, touchstartY = 0, touchendY = 0;
    let debounceTimeout;

    function handleGesture() {
        console.log('Handling swipe gesture...');
        console.log(`touchstartX: ${touchstartX}, touchendX: ${touchendX}`);
        console.log(`touchstartY: ${touchstartY}, touchendY: ${touchendY}`);
        if (touchendX < touchstartX - 50) {
            document.getElementById('rightSidebar').classList.add('visible');
        }
        if (touchendX > touchstartX + 50) {
            document.getElementById('leftSidebar').classList.add('visible');
        }
        if (touchendY < touchstartY - 50) {
            document.getElementById('mainContainer').classList.add('hidden');
        }
        if (touchendY > touchstartY + 50) {
            document.getElementById('mainContainer').classList.remove('hidden');
            document.getElementById('leftSidebar').classList.remove('visible');
            document.getElementById('rightSidebar').classList.remove('visible');
        }
    }

    document.addEventListener('touchstart', e => {
        touchstartX =