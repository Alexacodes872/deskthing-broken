async function onMessageFromMain(event, ...args) {
    const messageType = event;
    const messageRequest = args[0];
    const data = args[1];

    // Handle the message based on the type and request
    switch (messageType) {
        case 'music':
            handleMusicRequest(messageRequest, data);
            break;
        // Add more cases as needed
        default:
            console.log('Unknown message type:', messageType);
    }
}

function handleMusicRequest(request, data) {
    switch (request) {
        case 'next':
            // Handle next track
            console.log('Next track:', data);
            break;
        case 'previous':
            // Handle previous track
            console.log('Previous track');
            break;
        case 'rewind':
            // Handle rewind
            console.log('Rewind:', data);
            break;
        case 'fast_forward':
            // Handle fast forward
            console.log('Fast forward:', data);
            break;
        case 'play':
            // Handle play
            console.log('Play:', data);
            break;
        case 'pause':
            // Handle pause
            console.log('Pause:', data);
            break;
        case 'seek':
            // Handle seek
            console.log('Seek to position:', data);
            break;
        case 'like':
            // Handle like
            console.log('Like:', data);
            break;
        case 'volume':
            // Handle volume change
            console.log('Volume:', data);
            break;
        case 'repeat':
            // Handle repeat mode
            console.log('Repeat mode:', data);
            break;
        case 'shuffle':
            // Handle shuffle mode
            console.log('Shuffle mode:', data);
            break;
        case 'song':
            // Get current song data
            console.log('Get song data');
            break;
        default:
            console.log('Unknown music request:', request);
    }
}