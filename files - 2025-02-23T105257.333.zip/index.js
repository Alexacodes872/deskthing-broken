module.exports = { start, onMessageFromMain, stop };

async function start({ sendDataToMain }) {
  // Initialize data for your app
  sendDataToMain('get', 'data');
  sendDataToMain('log', 'Discord app has started successfully!');

  // Add additional initialization logic here if needed
}

function onMessageFromMain(event, ...args) {
  switch (event) {
    case 'message':
      // Handle message event
      console.log('Received message:', args);
      break;

    case 'data':
      // Handle data event
      console.log('Received data:', args);
      break;

    case 'callback-data':
      // Handle callback-data event
      console.log('Received callback data:', args);
      break;

    case 'get':
      // Handle get event
      if (args[0] === 'manifest') {
        console.log('Manifest requested');
      }
      break;

    case 'set':
      // Handle set event
      if (args[0] === 'update_setting') {
        console.log('Settings updated:', args[1]);
      }
      break;

    default:
      console.log('Unknown event:', event, args);
  }
}

function stop() {
  // Cleanup any files or resources here
  console.log('Discord app is stopping.');
}